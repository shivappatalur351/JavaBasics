Your integration tests go in here.

Integration tests are run inside the Vert.x container