package jdbcc;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NumberIncrement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		int length=sc.nextInt();
		int result;
		
		List<Integer> list=new ArrayList<Integer>();
		
		for(int i=1;i<=length;i++) {
			result=number*i;
			list.add(result);
		}
		System.out.println(list);

	}

}
