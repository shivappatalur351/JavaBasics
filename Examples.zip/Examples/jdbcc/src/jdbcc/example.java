package jdbcc;

import java.io.*;
import java.sql.*;
import java.util.*;



public class example {

	private static final String Db_Driver="driver";
	private static final String Db_User="user";
	private static final String Db_Password="password";
	private static final String Db_Url="url";
	private static  Properties  properties=null;

	public static void main(String[] args) {

try {
	File file=new File("application.properties");
	properties=new Properties();
	    properties.load(new FileReader(file));
	  Class.forName(example.decode(properties.getProperty(Db_Driver)));
	  Connection con=DriverManager.getConnection(decode(properties.getProperty(Db_Url)),decode(properties.getProperty(Db_User)),decode(properties.getProperty(Db_Password)));
		
if(con!=null)
{
	System.out.println("Connection successfully");
}
else {
	System.out.println("not connected!!!");
}
}	
catch(Exception e) {
			System.out.println(e);
		}
		  
	}
	private static String decode(String property) {
		// TODO Auto-generated method stub
		byte str1[]=Base64.getDecoder().decode(property);
		String result=new String(str1);
		return result ;
	}
	
}
