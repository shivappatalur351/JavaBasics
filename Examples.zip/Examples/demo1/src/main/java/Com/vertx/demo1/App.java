package Com.vertx.demo1;

import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Vertx;
import io.vertx.core.file.FileProps;
import io.vertx.core.file.FileSystem;
import io.vertx.core.http.HttpServer;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Vertx v=Vertx.vertx();
        
        HttpServer server=v.createHttpServer();
        
    server.requestHandler(request -> {
    	request.response().end("hello world!");
    	 }).listen(8088);
   /* v.setPeriodic(1000, id -> {
    	  // This handler will get called every second
    	  System.out.println("timer fired!");
    	});*/
    FileSystem fs = v.fileSystem();

    Future<FileProps> future = fs.props("one.txt");

    future.onComplete((AsyncResult<FileProps> ar) -> {
      if (ar.succeeded()) {
        FileProps props = ar.result();
        System.out.println("File size = " + props.size());
      } else {
        System.out.println("Failure: " + ar.cause().getMessage());
      }
    });
    }
}
